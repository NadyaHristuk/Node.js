import React from 'react';

class NotfoundPage extends React.Component {
    
    render(){
      return (
        <div>
            <h1 className="page-title"> Page not found :( </h1>                        

            <p> The link may be broken, or the page may have been removed </p>

        </div>
    )}
}

export default NotfoundPage;