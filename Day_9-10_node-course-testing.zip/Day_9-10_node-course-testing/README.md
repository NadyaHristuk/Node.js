# Node course (code examples)

### REST API (Express example)

#### Distributed template
